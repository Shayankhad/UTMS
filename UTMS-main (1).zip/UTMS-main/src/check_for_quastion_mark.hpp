#ifndef CHECK_FOR_QUASTION_MARK_HPP
#define CHECK_FOR_QUASTION_MARK_HPP
#include "global.hpp"

void check_for_quastion_mark(string command);

#endif