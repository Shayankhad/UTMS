#ifndef EXTRACT_MAJORS_CSV_HPP
#define EXTRACT_MAJORS_CSV_HPP
#include "global.hpp"
void extract_majors_csv(string address, vector<Major*> &majors);
#endif
