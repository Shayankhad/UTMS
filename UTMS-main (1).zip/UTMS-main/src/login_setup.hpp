#ifndef LOGIN_SETUP_HPP
#define LOGIN_SETUP_HPP
#include "global.hpp"

void login_setup(string arg_1_value , string arg_2_value , vector<Student *> &students, vector<Professor *> &professors, UtAccount *ut_account_ptr);

#endif