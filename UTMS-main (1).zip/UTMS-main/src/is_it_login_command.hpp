#ifndef IS_IT_LOGIN_COMMAND_HPP
#define IS_IT_LOGIN_COMMAND_HPP
#include "global.hpp"

bool is_it_login_command(string command);

#endif
