#ifndef STRING_TO_INT_HPP
#define STRING_TO_INT_HPP
#include "global.hpp"
int string_to_int(string str);
#endif