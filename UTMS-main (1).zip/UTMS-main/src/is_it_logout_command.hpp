#ifndef IS_IT_LOGOUT_COMMAND_HPP
#define IS_IT_LOGOUT_COMMAND_HPP
#include "global.hpp"

bool is_it_logout_command(string command);

#endif