#ifndef EXTRACT_PROFESSORS_CSV_HPP
#define EXTRACT_PROFESSORS_CSV_HPP
#include "global.hpp"
void extract_professors_csv(string address , vector<Professor*> &professors);
#endif