#ifndef CONNECT_COMMAND_HPP
#define CONNECT_COMMAND_HPP
#include "global.hpp"

void connect_command(string command, vector<Student *> &students, vector<Professor *> &professors, UtAccount *ut_account_ptr);

#endif
