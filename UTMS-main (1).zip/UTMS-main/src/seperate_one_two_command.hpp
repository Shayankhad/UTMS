#ifndef SEPERATE_ONE_TWO_COMMAND_HPP
#define SEPERATE_ONE_TWO_COMMAND_HPP
#include "global.hpp"
vector<string> seperate_one_two_command(string command);
#endif
