#ifndef IDENTIFY_USER_HPP
#define IDENTIFY_USER_HPP

#include "global.hpp"

int identify_user(vector<Student *> students, vector<Professor *> professors, UtAccount *ut_account_ptr);

#endif

