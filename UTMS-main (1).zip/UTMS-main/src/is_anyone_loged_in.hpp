#ifndef IS_ANYONE_LOGED_INT_HPP
#define IS_ANYONE_LOGED_INT_HPP
#include "global.hpp"

bool is_anyone_loged_in(vector<Student *> students, vector<Professor *> professors, UtAccount *ut_account_ptr);

#endif
