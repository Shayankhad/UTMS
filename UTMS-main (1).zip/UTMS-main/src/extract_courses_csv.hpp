#ifndef EXTRACT_COURSES_CSV_HPP
#define EXTRACT_COURSES_CSV_HPP
#include "global.hpp"
void extract_courses_csv(string address , vector<Course*> &courses);
#endif