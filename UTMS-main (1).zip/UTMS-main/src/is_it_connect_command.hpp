#ifndef IS_IT_CONNECT_COMMAND
#define IS_IT_CONNECT_COMMAND
#include "global.hpp"

bool is_it_connect_command(string command);

#endif
