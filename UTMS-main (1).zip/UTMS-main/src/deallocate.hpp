#ifndef DEALLOCATE_HPP
#define DEALLOCATE_HPP
#include"global.hpp"
void deallocate(vector<Major *> &majors , vector<Student *> &students , vector<Course *> &courses ,vector<Professor *> &professors , UtAccount *ut_account_ptr );
#endif
