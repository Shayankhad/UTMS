#ifndef LOGIN_COMMAND_HPP
#define LOGIN_COMMAND_HPP
#include "global.hpp"

void login_command(string command, vector<Student *> &students, vector<Professor *> &professors, UtAccount *ut_account_ptr);

#endif