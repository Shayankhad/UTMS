#ifndef CHECK_FOR_SECOND_COMMANDS_HPP
#define CHECK_FOR_SECOND_COMMANDS_HPP
#include "global.hpp"
void check_for_second_commands(string command);
#endif