#ifndef CHECK_NUMBER_FILE_HPP
#define CHECK_NUMBER_FILE_HPP
#include "global.hpp"

int check_number_type(const string& str);

#endif