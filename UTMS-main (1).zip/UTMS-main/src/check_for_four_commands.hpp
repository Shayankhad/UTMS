#ifndef CHECK_FOR_FOUR_COMMANDS_HPP
#define CHECK_FOR_FOUR_COMMANDS_HPP
#include "global.hpp"
void check_for_four_commands(string command);
#endif
