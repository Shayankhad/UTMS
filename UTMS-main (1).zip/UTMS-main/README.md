2024-05-20
LIFE IS HARD
2024-05-25
I hate this fucking errors 
swear to god if one shows up again i will kill my family after i killed my self.


