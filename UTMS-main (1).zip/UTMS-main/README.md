2024-05-20
LIFE IS HARD
2024-05-25
I hate this fucking errors 
swear to god if one shows up again i will kill my family after i killed my self.


1- error number 1:
make: *** [run] Error -1073741795
problem: had a wrong return type for a functino

2- error number 2:
make: *** [run] Error -1073741819
problem: there was some wrong with the makefile because the makefile couldnt consider the change of some hpp files (UNIPERSON CLASS) and was runing the old files and still i dont know why this happesn some times

3- third error:
always handel errors before doing the operator not in the middle of doing the operator.

4-fourth error:
it is important where to put the throw catch because some times its too late to throw an error cause the operator that we didnt want to do any thing did something

5- 
